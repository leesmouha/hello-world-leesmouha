from flask import Flask, render_template, redirect, url_for

app = Flask(__name__)


@app.route('/')
def index():
	return render_template('index.html')

@app.route('/assignment8')
def assignment():
	data = {
	"hobbies":["Learning new things", "Reading books", "Cooking"],
	"preferences":[ ["Dua Lipa", "Charlie Puth", "Chris Brown"], ["Action films", "Gal Gabot"] ]
	}
	return render_template('assignment8.html', data=data)

@app.route('/<file>')
def fileOpen(file):
	if file.find('.html')!=-1:
		return render_template(file)
	return redirect(url_for('static', filename=file))

if __name__ == '__main__':
	app.run()