
var counter = 0;

function ContactMe() {
    if (counter == 0) {
        alert("Don't Forget to Contact Me");
        changeColor("turquoise");
        document.getElementById("ContactMe").innerHTML = "Click Me"

        counter = counter + 1;
    }
     
}

function changeColor(color) {
    document.getElementById("ContactMe").style.background = color;
}

function formSubmitted() {
    alert("Thank you, I will contact you soon!");
}
