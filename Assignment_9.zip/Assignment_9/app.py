from flask import Flask, render_template, redirect, request, session

app = Flask(__name__)
app.secret_key = "abc" #for session usage

usersList = [ { "name":"Liav", "email":"liavshab@gmail.com"}, 
{ "name":"Lindsay Ferguson", "email":"lindsay.ferguson@reqres.in" }, 
{ "name":"Michael Lawson", "email":"michael.lawson@reqres.in" } ]

@app.route('/')
def index():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template('index.html', greeting=greeting)

@app.route('/education')
def education():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template('education.html', greeting=greeting)


@app.route('/skills')
def skills():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template('skills.html', greeting=greeting)


@app.route('/work')
def work():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template('work.html', greeting=greeting)


@app.route('/contactMe')
def contactMe():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template('contactMe.html', greeting=greeting)


@app.route('/contact_List')
def contact_list():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template('MyContactList.html', greeting=greeting)


@app.route('/Hobbies')
def Hobbies():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	viewingUser = "Liav"
	tvShows = ["Lost", "Breaking Bad", "Better Call Saul"]
	return render_template('Hobbies.html', name=viewingUser, tv=tvShows, greeting=greeting)


@app.route('/noPage')
def erroPage():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template("404 Error.html", greeting=greeting)

@app.route('/linkedin')
def linkedin():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return redirect("https://www.linkedin.com/in/liav-shabtai", greeting=greeting)


@app.route('/assignment9', methods=["GET", "POST"])
def assignment9():
	listToSend = [ ]
	if request.args.get("search")!=None:
		searchVal = request.args.get("search")
		for x in usersList:
			if x["name"].find(searchVal)!=-1 or x["email"].find(searchVal)!=-1:
				listToSend.append(x)
	elif "name" in request.form:
		usersList.append({ "name":request.form["name"], "email":request.form["email"] })
		session["greeting"] = request.form["name"]
	elif "logout" in request.form:
		session.clear()

	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template("assignment9.html", users=listToSend, greeting=greeting)

if __name__ == '__main__':
	app.run(debug=True)
